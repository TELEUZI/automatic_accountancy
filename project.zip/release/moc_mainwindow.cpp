/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[31];
    char stringdata0[509];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 13), // "load_database"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 9), // "set_table"
QT_MOC_LITERAL(4, 36, 13), // "QTableWidget*"
QT_MOC_LITERAL(5, 50, 6), // "string"
QT_MOC_LITERAL(6, 57, 10), // "set_tables"
QT_MOC_LITERAL(7, 68, 1), // "z"
QT_MOC_LITERAL(8, 70, 15), // "vector<worker>&"
QT_MOC_LITERAL(9, 86, 6), // "result"
QT_MOC_LITERAL(10, 93, 17), // "number_of_workers"
QT_MOC_LITERAL(11, 111, 13), // "delete_worker"
QT_MOC_LITERAL(12, 125, 7), // "show_if"
QT_MOC_LITERAL(13, 133, 24), // "average_and_whole_salary"
QT_MOC_LITERAL(14, 158, 14), // "add_new_worker"
QT_MOC_LITERAL(15, 173, 7), // "string*"
QT_MOC_LITERAL(16, 181, 4), // "find"
QT_MOC_LITERAL(17, 186, 14), // "vector<worker>"
QT_MOC_LITERAL(18, 201, 21), // "on_buttonBox_accepted"
QT_MOC_LITERAL(19, 223, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(20, 245, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(21, 269, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(22, 293, 23), // "on_pushButton_4_clicked"
QT_MOC_LITERAL(23, 317, 23), // "on_pushButton_5_clicked"
QT_MOC_LITERAL(24, 341, 23), // "on_pushButton_6_clicked"
QT_MOC_LITERAL(25, 365, 23), // "on_pushButton_7_clicked"
QT_MOC_LITERAL(26, 389, 23), // "on_pushButton_8_clicked"
QT_MOC_LITERAL(27, 413, 23), // "on_pushButton_9_clicked"
QT_MOC_LITERAL(28, 437, 24), // "on_pushButton_10_clicked"
QT_MOC_LITERAL(29, 462, 24), // "on_pushButton_11_clicked"
QT_MOC_LITERAL(30, 487, 21) // "on_buttonBox_rejected"

    },
    "MainWindow\0load_database\0\0set_table\0"
    "QTableWidget*\0string\0set_tables\0z\0"
    "vector<worker>&\0result\0number_of_workers\0"
    "delete_worker\0show_if\0average_and_whole_salary\0"
    "add_new_worker\0string*\0find\0vector<worker>\0"
    "on_buttonBox_accepted\0on_pushButton_clicked\0"
    "on_pushButton_2_clicked\0on_pushButton_3_clicked\0"
    "on_pushButton_4_clicked\0on_pushButton_5_clicked\0"
    "on_pushButton_6_clicked\0on_pushButton_7_clicked\0"
    "on_pushButton_8_clicked\0on_pushButton_9_clicked\0"
    "on_pushButton_10_clicked\0"
    "on_pushButton_11_clicked\0on_buttonBox_rejected"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  119,    2, 0x08 /* Private */,
       3,    8,  120,    2, 0x08 /* Private */,
       6,    3,  137,    2, 0x08 /* Private */,
      11,    0,  144,    2, 0x08 /* Private */,
      12,    0,  145,    2, 0x08 /* Private */,
      13,    0,  146,    2, 0x08 /* Private */,
      14,    2,  147,    2, 0x08 /* Private */,
      16,    2,  152,    2, 0x08 /* Private */,
      18,    0,  157,    2, 0x08 /* Private */,
      19,    0,  158,    2, 0x08 /* Private */,
      20,    0,  159,    2, 0x08 /* Private */,
      21,    0,  160,    2, 0x08 /* Private */,
      22,    0,  161,    2, 0x08 /* Private */,
      23,    0,  162,    2, 0x08 /* Private */,
      24,    0,  163,    2, 0x08 /* Private */,
      25,    0,  164,    2, 0x08 /* Private */,
      26,    0,  165,    2, 0x08 /* Private */,
      27,    0,  166,    2, 0x08 /* Private */,
      28,    0,  167,    2, 0x08 /* Private */,
      29,    0,  168,    2, 0x08 /* Private */,
      30,    0,  169,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4, 0x80000000 | 5, 0x80000000 | 5, 0x80000000 | 5, 0x80000000 | 5, QMetaType::Double, QMetaType::Int, QMetaType::Int,    2,    2,    2,    2,    2,    2,    2,    2,
    QMetaType::Void, 0x80000000 | 4, 0x80000000 | 8, QMetaType::Int,    7,    9,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Double,
    QMetaType::Void, 0x80000000 | 15, QMetaType::Double,    2,    2,
    0x80000000 | 17, 0x80000000 | 5, QMetaType::Int,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->load_database(); break;
        case 1: _t->set_table((*reinterpret_cast< QTableWidget*(*)>(_a[1])),(*reinterpret_cast< string(*)>(_a[2])),(*reinterpret_cast< string(*)>(_a[3])),(*reinterpret_cast< string(*)>(_a[4])),(*reinterpret_cast< string(*)>(_a[5])),(*reinterpret_cast< double(*)>(_a[6])),(*reinterpret_cast< int(*)>(_a[7])),(*reinterpret_cast< int(*)>(_a[8]))); break;
        case 2: _t->set_tables((*reinterpret_cast< QTableWidget*(*)>(_a[1])),(*reinterpret_cast< vector<worker>(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 3: _t->delete_worker(); break;
        case 4: _t->show_if(); break;
        case 5: { double _r = _t->average_and_whole_salary();
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = std::move(_r); }  break;
        case 6: _t->add_new_worker((*reinterpret_cast< string*(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 7: { vector<worker> _r = _t->find((*reinterpret_cast< string(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< vector<worker>*>(_a[0]) = std::move(_r); }  break;
        case 8: _t->on_buttonBox_accepted(); break;
        case 9: _t->on_pushButton_clicked(); break;
        case 10: _t->on_pushButton_2_clicked(); break;
        case 11: _t->on_pushButton_3_clicked(); break;
        case 12: _t->on_pushButton_4_clicked(); break;
        case 13: _t->on_pushButton_5_clicked(); break;
        case 14: _t->on_pushButton_6_clicked(); break;
        case 15: _t->on_pushButton_7_clicked(); break;
        case 16: _t->on_pushButton_8_clicked(); break;
        case 17: _t->on_pushButton_9_clicked(); break;
        case 18: _t->on_pushButton_10_clicked(); break;
        case 19: _t->on_pushButton_11_clicked(); break;
        case 20: _t->on_buttonBox_rejected(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QTableWidget* >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QTableWidget* >(); break;
            }
            break;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
