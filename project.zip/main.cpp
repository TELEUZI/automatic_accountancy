#include "mainwindow.h"
#include <QApplication>
#include <QTranslator>
#include <QLibraryInfo>
int main(int argc, char *argv[])
{

    QApplication a(argc, argv);
    //set translator for qhelpsearchquerywidget
      QTranslator qtHelpTranslator;
      qtHelpTranslator.load("qt_help_ru",QLibraryInfo::location(QLibraryInfo::TranslationsPath));
      a.installTranslator(&qtHelpTranslator);

      //set translator for default widget's text (for example: QMessageBox's buttons)
      QTranslator qtTranslator;
      qtTranslator.load("qt_ru",QLibraryInfo::location(QLibraryInfo::TranslationsPath));
      a.installTranslator(&qtTranslator);
    MainWindow w;
    w.show();
    return a.exec();
}
